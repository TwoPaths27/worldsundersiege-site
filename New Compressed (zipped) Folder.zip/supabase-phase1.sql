-- Worlds Under Siege — Phase 1 account foundation
-- Run this entire file once in Supabase: SQL Editor → New query → Run.

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  onboarding_step text not null default 'download_images',
  onboarding_complete boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists profiles_username_lower_unique
on public.profiles (lower(username));

alter table public.profiles enable row level security;

grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;

drop policy if exists "Players can read own profile" on public.profiles;
create policy "Players can read own profile"
on public.profiles
for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Players can update own profile" on public.profiles;
create policy "Players can update own profile"
on public.profiles
for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_username text;
begin
  requested_username := trim(new.raw_user_meta_data ->> 'username');

  if requested_username is null
     or requested_username !~ '^[A-Za-z0-9_-]{3,24}$' then
    raise exception 'Invalid username';
  end if;

  insert into public.profiles (
    user_id,
    username,
    onboarding_step,
    onboarding_complete
  )
  values (
    new.id,
    requested_username,
    'download_images',
    false
  );

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_profile_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
before update on public.profiles
for each row execute procedure public.set_profile_updated_at();
